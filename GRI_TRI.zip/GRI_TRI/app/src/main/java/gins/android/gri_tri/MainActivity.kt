package gins.android.gri_tri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.smarteist.autoimageslider.SliderAnimations

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val imageSliderAdapter=ImageSliderAdapter(this)

        main_image_slider.(imageSliderAdapter)
        main_image_slider.setSliderTransformaAnimation(SliderAnimations.SIMPLETRANSFORMATION)
        main_image_slider.startAutoCycle()

        imageSliderAdapter.renewItems(fetchSliderItemList())

        main_recycler_view.apply{
            adapter=ItemListAdapter()
            layoutManager=LinearLayoutManager(context)
        }

        main_recycler.apply{
            adapter=ItemList2Adapter()
            layoutManager=LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false)
        }



    }

    private fun fetchSliderItemList(): List<String>{
        val items= arrayListOf<String>()
        items.add("https://images.pexels.com/photos/1974508/pexels-photo-1974508.jpeg?cs=srgb&dl=pexels-julia-kuzenkov-1974508.jpg&fm=jpg")
        items.add("https://images.pexels.com/photos/808510/pexels-photo-808510.jpeg?cs=srgb&dl=pexels-muhammad-khairul-iddin-adnan-808510.jpg&fm=jpg")
        items.add("https://images.pexels.com/photos/1005715/pexels-photo-1005715.jpeg?cs=srgb&dl=pexels-irina-iriser-1005715.jpg&fm=jpg")
        return items

    }
}